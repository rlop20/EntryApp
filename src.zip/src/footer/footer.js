import React from 'react';
import './footer.css';

function Footer() {
  return (
    <div className="footer">
      <p>&copy; 2024 Entry, Powered by &copy; Twen Studios</p>
    </div>
  );
}

export default Footer;
