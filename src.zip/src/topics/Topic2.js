import React from 'react';
import './topicCSS.css'

const Topic1 = () => {
  return (
    <div className='main'>
      <h1>What is Programming?</h1>
      <p> 
        Programming is making your computer do something by creating a program.
        We program by using a programming language, using a text editor to write code
        called IDEs, and save/run the code. Programming and code go hand and hand, we program
        by writing code.
      </p>
    </div>
  );
}

export default Topic1;
